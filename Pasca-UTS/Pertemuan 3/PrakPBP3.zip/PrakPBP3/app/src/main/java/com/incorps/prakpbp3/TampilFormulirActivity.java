package com.incorps.prakpbp3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TampilFormulirActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_formulir);

        TextView nim = findViewById(R.id.nim);
        TextView nama = findViewById(R.id.nama);
        TextView tglLahir = findViewById(R.id.tgl_lahir);
        TextView alamat = findViewById(R.id.alamat);
        TextView email = findViewById(R.id.email);
        TextView password = findViewById(R.id.password);

        nim.setText(getIntent().getStringExtra("nim"));
        nama.setText(getIntent().getStringExtra("nama"));
        tglLahir.setText(getIntent().getStringExtra("tglLahir"));
        alamat.setText(getIntent().getStringExtra("alamat"));
        email.setText(getIntent().getStringExtra("email"));
        password.setText(getIntent().getStringExtra("password"));
    }
}
