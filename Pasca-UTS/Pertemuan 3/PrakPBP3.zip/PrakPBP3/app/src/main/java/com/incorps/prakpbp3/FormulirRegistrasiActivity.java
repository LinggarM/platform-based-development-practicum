package com.incorps.prakpbp3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FormulirRegistrasiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulir_registrasi);

        final Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nim = findViewById(R.id.nim);
                EditText nama = findViewById(R.id.nama);
                EditText tglLahir = findViewById(R.id.tgl_lahir);
                EditText alamat = findViewById(R.id.alamat);
                EditText email = findViewById(R.id.email);
                EditText password = findViewById(R.id.password);

                String mNim = nim.getText().toString().trim();
                String mNama = nama.getText().toString().trim();
                String mTglLahir = tglLahir.getText().toString().trim();
                String mAlamat = alamat.getText().toString().trim();
                String mEmail  = email.getText().toString().trim();
                String mPassword = password.getText().toString().trim();

                Intent intent = new Intent(FormulirRegistrasiActivity.this, TampilFormulirActivity.class);
                intent.putExtra("nim", mNim);
                intent.putExtra("nama", mNama);
                intent.putExtra("tglLahir", mTglLahir);
                intent.putExtra("alamat", mAlamat);
                intent.putExtra("email", mEmail);
                intent.putExtra("password", mPassword);
                startActivity(intent);
            }
        });
    }
}
